import pip 
pip.main(['install','speedtest-cli'])